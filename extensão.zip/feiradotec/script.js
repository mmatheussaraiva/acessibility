let currentFontSize = 16;

document.getElementById('increaseFont').addEventListener('click', () => {
  currentFontSize += 2;
  document.body.style.fontSize = currentFontSize + 'px';
});

document.getElementById('decreaseFont').addEventListener('click', () => {
  currentFontSize = Math.max(12, currentFontSize - 2);
  document.body.style.fontSize = currentFontSize + 'px';
});

// Ativar Alto Contraste
document.getElementById('highContrast').addEventListener('click', () => {
  document.body.classList.add('high-contrast');
});

document.getElementById('resetContrast').addEventListener('click', () => {
  document.body.classList.remove('high-contrast');
});

// Ativar Leitor de Tela
document.getElementById('screenReader').addEventListener('click', () => {
  let allText = document.body.innerText;
  let speech = new SpeechSynthesisUtterance(allText);
  window.speechSynthesis.speak(speech);
});

// Traduzir para Libras (Simulação de API)
document.getElementById('libras').addEventListener('click', () => {
  alert("API de tradução para Libras será integrada aqui.");
});
